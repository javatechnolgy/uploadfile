package pk.waseem.task.exception;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import pk.waseem.task.model.ResponseInfo;

@Qualifier("GlobalExceptionHandler")
@ControllerAdvice(annotations = RestController.class)
public class GlobalExceptionHandler {

	@ExceptionHandler(GeneralException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public @ResponseBody ResponseInfo handleValidation(final GeneralException exception) {
		ResponseInfo response = new ResponseInfo();
		response.setMessage(exception.getMessage());
		return response;
	}

	@ExceptionHandler(Throwable.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public @ResponseBody ResponseInfo handleValidation(final Throwable exception) {
		ResponseInfo response = new ResponseInfo();
		response.setMessage(exception.getMessage());
		return response;
	}
}