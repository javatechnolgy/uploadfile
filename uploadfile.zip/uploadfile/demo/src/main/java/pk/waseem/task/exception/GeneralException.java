package pk.waseem.task.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class GeneralException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String message;

	public GeneralException(String message) {
		this.message = message;
	}

	public GeneralException(String message, Throwable error) {
		super(error);
		this.message = message;
	}

}