package pk.waseem.task.sftp;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

import lombok.extern.slf4j.Slf4j;
import pk.waseem.task.exception.GeneralException;

@Slf4j
@Service
public class SftpServiceImpl implements SftpService {

	@Autowired
	private SftpProperties config;

	// Set the prompt when logging in for the first time. Optional value: (ask | yes
	// | no)
	private static final String SESSION_CONFIG_STRICT_HOST_KEY_CHECKING = "StrictHostKeyChecking";

	/**
	 * 
	 * @return
	 */
	private ChannelSftp createSftp() {
		try {
			JSch jsch = new JSch();

			Session session = createSession(jsch, config.getHost(), config.getUsername(), config.getPort());
			session.setPassword(config.getPassword());
			session.connect(config.getSessionConnectTimeout());

			Channel channel = session.openChannel(config.getProtocol());
			channel.connect(config.getChannelConnectedTimeout());

			return (ChannelSftp) channel;
		} catch (Throwable e) {
			throw new GeneralException("Create Sftp Failure, " + e.getMessage());
		}
	}

	/**
	 * 
	 * @param jsch
	 * @param host
	 * @param username
	 * @param port
	 * @return
	 * @throws Exception
	 */
	private Session createSession(JSch jsch, String host, String username, Integer port) throws Exception {
		Session session = null;

		if (port <= 0) {
			session = jsch.getSession(username, host);
		} else {
			session = jsch.getSession(username, host, port);
		}

		if (session == null) {
			throw new Exception(host + " session is null");
		}

		session.setConfig(SESSION_CONFIG_STRICT_HOST_KEY_CHECKING, config.getSessionStrictHostKeyChecking());
		return session;
	}

	/**
	 * 
	 * @param sftp
	 */
	private void disconnect(ChannelSftp sftp) {
		try {
			sftp.disconnect();
		} catch (Throwable e) {
		}

		try {
			sftp.getSession().disconnect();
		} catch (Throwable e) {
		}
	}

	/**
	 * 
	 * @param dirPath
	 * @param sftp
	 * @return
	 */
//	private boolean createDirs(String dirPath, ChannelSftp sftp) {
//		if (dirPath != null && !dirPath.isEmpty() && sftp != null) {
//			String[] dirs = Arrays.stream(dirPath.split("/")).filter(StringUtils::isNotBlank).toArray(String[]::new);
//
//			for (String dir : dirs) {
//				try {
//					sftp.cd(dir);
//					log.info("Change directory {}", dir);
//				} catch (Exception e) {
//					try {
//						sftp.mkdir(dir);
//						log.info("Create directory {}", dir);
//					} catch (SftpException e1) {
//						log.error("Create directory failure, directory:{}", dir, e1);
//					}
//					try {
//						sftp.cd(dir);
//						log.info("Change directory {}", dir);
//					} catch (SftpException e1) {
//						log.error("Change directory failure, directory:{}", dir, e1);
//					}
//				}
//			}
//			return true;
//		}
//		return false;
//	}

	/**
	 * 
	 */
	@Override
	public File downloadFile(final String fileName) {
		ChannelSftp sftp = this.createSftp();
		OutputStream outputStream = null;
		try {
			sftp.cd(config.getRoot());

			// File file = new File(targetPath.substring(targetPath.lastIndexOf("/") + 1));
			File file = new File(fileName);

			outputStream = new FileOutputStream(file);
			sftp.get(fileName.substring(fileName.lastIndexOf("/") + 1), outputStream);
			return file;
		} catch (Exception e) {
			throw new GeneralException("Download File failure");
		} finally {
			try {
				outputStream.close();
			} catch (IOException e) {

			}
			this.disconnect(sftp);
		}
	}

	/**
	 * 
	 */
	@Override
	public boolean deleteFile(final String fileName) {
		ChannelSftp sftp = null;
		try {
			sftp = this.createSftp();
			sftp.cd(config.getRoot());
			sftp.rm(fileName);
			return true;
		} catch (Exception e) {
			throw new GeneralException("Delete File failure");
		} finally {
			this.disconnect(sftp);
		}
	}

	/**
	 * 
	 */
	@Override
	public boolean uploadFile(final String fileName, InputStream inputStream) {
		ChannelSftp sftp = this.createSftp();
		try {
			sftp.cd(config.getRoot());

//			int index = targetPath.lastIndexOf("/");
//			String fileDir = targetPath.substring(0, index);
//			String fileName = targetPath.substring(index + 1);
//			boolean dirs = this.createDirs(fileDir, sftp);
//			if (!dirs) {
//				log.error("Remote path error. path:{}", targetPath);
//				throw new GeneralException("Upload File failure");
//			}
			sftp.put(inputStream, fileName);
			return true;
		} catch (Exception e) {

			throw new GeneralException("Upload File failure");
		} finally {
			this.disconnect(sftp);
		}
	}

	/**
	 * 
	 */
	@Override
	public boolean uploadFile(final String fileName, File file) {
		try {
			return this.uploadFile(fileName, new FileInputStream(file));
		} catch (FileNotFoundException e) {

			throw new GeneralException("Source File not found", e);
		}
	}

	/**
	 * 
	 */
	@Override
	public boolean isFileExist(String fileName) {
		ChannelSftp sftp = this.createSftp();
		try {
			sftp.cd(config.getRoot());

			try {
				sftp.ls(fileName);
				return true;
			} catch (SftpException e) {
				if (e.id == ChannelSftp.SSH_FX_NO_SUCH_FILE)
					return false;
				throw e;
			}
		} catch (Exception e) {
			throw new GeneralException("File exist check failure");
		} finally {
			this.disconnect(sftp);
		}
	}

}