package pk.waseem.task.sftp;

import java.io.File;
import java.io.InputStream;

public interface SftpService {

	boolean uploadFile(final String fileName, InputStream inputStream);

	boolean uploadFile(final String fileName, File file);

	File downloadFile(final String fileName);

	boolean deleteFile(final String fileName);

	boolean isFileExist(final String fileName);
}