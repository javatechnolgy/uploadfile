package pk.waseem.task.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import pk.waseem.task.model.ResponseInfo;
import pk.waseem.task.service.Action;

@RestController
@Api(value = "Guidelines", description = "This Api for File Upload")
@Validated
public class Controller {

	@Autowired
	Action performAction;

	@GetMapping("/hello")
	public ResponseEntity<ResponseInfo> sayHello() {
		return new ResponseEntity<ResponseInfo>(performAction.sayHello(), HttpStatus.OK);
	}

	@PostMapping(value = "/upload")
	@ApiOperation(value = "POST request to upload file", produces = "application/json", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	@ApiResponses(value = { @ApiResponse(code = 204, message = "File Received Successfully") })
	public ResponseEntity<Integer> uploadFile(
			@ApiParam(name = "file", value = "CSV file", required = true) @RequestPart("file") MultipartFile file) throws IOException {
		performAction.perform(file);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
}
