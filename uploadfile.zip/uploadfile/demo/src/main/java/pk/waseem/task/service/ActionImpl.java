package pk.waseem.task.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.slf4j.Slf4j;
import pk.waseem.task.exception.GeneralException;
import pk.waseem.task.model.ResponseInfo;
import pk.waseem.task.sftp.SftpService;

@Slf4j
@Component
public class ActionImpl implements Action {

	@Autowired
	private SftpService sftpService;

	private static ArrayList<String> validFileMimeType = new ArrayList<String>();

	static {
		validFileMimeType.add("text/csv");
		validFileMimeType.add("text/plain");
		validFileMimeType.add("application/vnd.ms-excel");
	}

	@Value("${local.uploads.file.base.path}")
	String uploadFileBasePath;

	@Value("${local.downloads.file.base.path}")
	String downloadFileBasePath;

	@Override
	public ResponseInfo sayHello() {
		return new ResponseInfo();
	}

	@Override
	public void perform(MultipartFile multiPartFile) throws IOException {
		final String fileName = multiPartFile.getOriginalFilename();
		File downlodedFile = null;
		File mergedFile = null;

		// Validating file type
		validateFileType(multiPartFile);

		File uploadFile = new File(uploadFileBasePath + fileName);
		try {
			FileUtils.writeByteArrayToFile(uploadFile, multiPartFile.getBytes());

			// File content is valid (2 columns only)
			isValidContent(uploadFile);
		} catch (IOException e) {
			throw new GeneralException("Unable to write uploaded file, " + e.getMessage());
		}

		// First check if file exists
		if (sftpService.isFileExist(fileName)) {
			// File exists on sftp than download that file on local repo
			downlodedFile = sftpService.downloadFile(downloadFileBasePath + fileName);
		}

		// check if content are updated flag =0 content updated

		int flag = isContentupdated(uploadFile.toPath().toString(), downlodedFile.toPath().toString());
		if (flag == 0) {

			List<String> csv1Headers = CsvParser.getHeadersFromACsv(uploadFile);

			List<String> csv2Headers = CsvParser.getHeadersFromACsv(downlodedFile);

			List<String> allCsvHeaders = new ArrayList<>();
			allCsvHeaders.addAll(csv1Headers);
			allCsvHeaders.addAll(csv2Headers);

			Set<String> uniqueHeaders = new HashSet<>(allCsvHeaders);
			List<CsvVo> csv1Records = CsvParser.getRecodrsFromACsv(uploadFile, csv1Headers);
			List<CsvVo> csv2Records = CsvParser.getRecodrsFromACsv(downlodedFile, csv2Headers);
			List<CsvVo> allCsvRecords = new ArrayList<>();
			allCsvRecords.addAll(csv1Records);
			allCsvRecords.addAll(csv2Records);
			mergedFile = new File(uploadFileBasePath + fileName);
			CsvParser.writeToCsv(mergedFile, uniqueHeaders, allCsvRecords);

			// Now Uploading the file on sftp, if already exist file will be over written
			if (sftpService.uploadFile(fileName, mergedFile)) {

				// File uploaded successfully than delete it from local dir
				if (uploadFile.delete()) {

					// log.info("File {} has been deleted successfuly from local dir", fileName);
				}
			}
		} else if (flag == 1) {

		}

		return;
	}

	/**
	 * 
	 * @param file
	 */
	private void validateFileType(final MultipartFile file) {
		// File extension validation
		if (!file.getOriginalFilename().toLowerCase().endsWith(".csv"))
			throw new GeneralException("Invalid file extension");

		// FIle name should be alpha numeric only to prevent any special character in
		// file name
		if (!file.getOriginalFilename().matches("^[a-zA-Z0-9\\._-]+$"))
			throw new GeneralException("File name should be alphanumeric only, allowed special characters are _ - .");

		// File content type validation
		if (file.getContentType() == null || !validFileMimeType.contains(file.getContentType().toLowerCase()))
			throw new GeneralException("Invalid file content-type");
	}

	/**
	 * 
	 * @param file
	 * @throws IOException
	 */
	private void isValidContent(File file) throws IOException {
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(file));
			String line = br.readLine();
			br.close();

			if (line.split(Pattern.quote(",")).length != 2) {
				file.delete();
				throw new GeneralException("Invalid number of columns");
			}
		} finally {
			try {
				br.close();
			} catch (Throwable e) {
			}
		}
	}

	public int isContentupdated(String uplodedFilePath, String remoteFilePath) throws IOException {
		FileReader fR1 = new FileReader(uplodedFilePath);
		FileReader fR2 = new FileReader(remoteFilePath);

		BufferedReader reader1 = new BufferedReader(fR1);
		BufferedReader reader2 = new BufferedReader(fR2);

		String line1 = null;
		String line2 = null;
		int flag = 1;
		while ((flag == 1) && ((line1 = reader1.readLine()) != null) && ((line2 = reader2.readLine()) != null)) {
			System.out.println(line1);
			System.out.println(line2);
			if (!line1.equalsIgnoreCase(line2))
				flag = 0;
			else
				flag = 1;
		}
		reader1.close();
		reader2.close();

		return flag;

	}

	public static void main(String[] args) throws IOException {
		File csv1 = new File("E:\\file.csv"); // OUTFILE
		File csv2 = new File("E:\\file1.csv"); // INPUT

		ActionImpl ob = new ActionImpl();
		int flag = ob.isContentupdated(csv1.toPath().toString(), csv2.toPath().toString());
		System.out.println(flag);

		List<String> csv1Headers = CsvParser.getHeadersFromACsv(csv1);
		// csv1Headers.forEach(h -> System.out.print(h + " "));
		// System.out.println();
		List<String> csv2Headers = CsvParser.getHeadersFromACsv(csv2);
		// csv2Headers.forEach(h -> System.out.print(h + " "));
		// System.out.println();
		List<String> allCsvHeaders = new ArrayList<>();
		allCsvHeaders.addAll(csv1Headers);
		allCsvHeaders.addAll(csv2Headers);
		// allCsvHeaders.forEach(h -> System.out.print(h + " "));
		// System.out.println();
		Set<String> uniqueHeaders = new HashSet<>(allCsvHeaders);
		// uniqueHeaders.forEach(h -> System.out.print(h + " "));
		// System.out.println();
		List<CsvVo> csv1Records = CsvParser.getRecodrsFromACsv(csv1, csv1Headers);
		List<CsvVo> csv2Records = CsvParser.getRecodrsFromACsv(csv2, csv2Headers);
		List<CsvVo> allCsvRecords = new ArrayList<>();
		allCsvRecords.addAll(csv1Records);
		allCsvRecords.addAll(csv2Records);
		CsvParser.writeToCsv(new File("E:\\merge.csv"), uniqueHeaders, allCsvRecords);
	}

}
