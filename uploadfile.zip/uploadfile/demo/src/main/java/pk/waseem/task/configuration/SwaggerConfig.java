package pk.waseem.task.configuration;

import java.net.UnknownHostException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

public class SwaggerConfig {
	@Value("${server.servlet.context-path}")
	private String contextPath;

	ApiInfo apiInfo() {
		return new ApiInfoBuilder().title("File Upload").description("This Api for uploading file")
				.license("waseem-ahmed.pk").licenseUrl("http://unlicense.org").termsOfServiceUrl("").version("1.0.0")
				.build();
	}

	@Bean
	public Docket customImplementation() throws UnknownHostException {

		return new Docket(DocumentationType.SWAGGER_2).select()
				.apis(RequestHandlerSelectors.basePackage("pk.waseem.controller")).build().apiInfo(apiInfo());
	}
}
