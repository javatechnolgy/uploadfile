package pk.waseem.task.service;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

import pk.waseem.task.model.ResponseInfo;

public interface Action {
	public ResponseInfo sayHello();

	public void perform(MultipartFile file) throws IOException;
}
